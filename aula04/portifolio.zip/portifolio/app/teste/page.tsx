export default function Page() {
    return <h1>Olá eu sou o Teste!</h1>
  }